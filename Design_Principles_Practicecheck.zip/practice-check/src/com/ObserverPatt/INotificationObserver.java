package com.ObserverPatt;

public interface INotificationObserver {
	  public void update();
}

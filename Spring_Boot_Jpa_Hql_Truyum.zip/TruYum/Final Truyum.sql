use truyum;

CREATE TABLE IF NOT EXISTS `cart` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `us_id` INT NULL,
  `c_id` INT NULL,
  PRIMARY KEY (`id`));
  
 CREATE TABLE IF NOT EXISTS `menuitem` (
  `pid` INT NOT NULL AUTO_INCREMENT,
  `id` INT NOT NULL,
  `name` VARCHAR(45) NOT NULL,
  `price` FLOAT NOT NULL,
  `active` BIT(2) NOT NULL,
  `dateOfLaunch` DATE NOT NULL,
  `category` VARCHAR(45) NOT NULL,
  `freeDelivery` BIT(2) NOT NULL,
  PRIMARY KEY (`pid`));
  
INSERT INTO `menuitem` (`pid`,`id`, `name`, `price`, `active`, `dateOfLaunch`, `category`, `freeDelivery`) 
VALUES ('1','10', 'sandwhich', '450', b'1', Date('2019/05/01'), 'FastFood', b'1');

INSERT INTO `menuitem` (`pid`,`id`, `name`, `price`, `active`, `dateOfLaunch`, `category`, `freeDelivery`) 
VALUES ('2','1', 'juice', '550', b'1', Date('2018/05/01'), 'FastFood', b'1');

INSERT INTO `menuitem` (`pid`,`id`, `name`, `price`, `active`, `dateOfLaunch`, `category`, `freeDelivery`) 
VALUES ('3','2', 'Cutlet', '450', b'1', Date('2019/4/01'), 'FastFood', b'1');
package com.cognizant.truyum.dao;

public class MenuItemDaoSqlImplTest {

	public static void main(String[] args) {

	}

	public static void testGetMenuItemListAdmin() {

	}

	public static void testGetMenuItemListCustomer() {

	}

	public static void testModifyMenuItem() {

	}

	public static void testGetMenuItem() {

	}
}
